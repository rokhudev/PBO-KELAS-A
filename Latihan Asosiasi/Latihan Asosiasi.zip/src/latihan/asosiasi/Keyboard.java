package latihan.asosiasi;

public class Keyboard {
    private String merk;
    
    public Keyboard(String m){
        merk = m;
    }
    
    public void tampilData(){
        System.out.println("Merk keyboard: " + merk);
    }
}
