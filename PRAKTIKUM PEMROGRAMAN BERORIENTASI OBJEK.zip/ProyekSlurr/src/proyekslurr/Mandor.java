
package proyekslurr;


public class Mandor {
    
}
