
package latihan.method;
public class LatihanMethod {

    public static void main(String[] args) {
        // object persegi
        Persegi persegi1=new Persegi(10);
        System.out.println("Output :");
        persegi1.tampilData();
        
        Persegi.infoClass();
    }
    
}
